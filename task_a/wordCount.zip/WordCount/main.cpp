#include <iostream>
#include <sstream>

void countWordsAndCharacters(const std::string& text){
    int wordCount = 0, charCount = text.length();
    std::istringstream stream(text);
    std::string word;

    while (stream >> word) {
        wordCount++; // Count words
    }

    std::cout << "Word Count: " << wordCount << "\n";
    std::cout << "Character Count: " << charCount << "\n";
}
int main() {
    std::string inputText;
    
    std::cout << "Enter a text: ";
    std::getline(std::cin, inputText);

    countWordsAndCharacters(inputText);
    return 0;
}
